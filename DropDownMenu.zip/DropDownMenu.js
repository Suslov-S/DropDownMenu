/*globals define*/
define( ["qlik", "jquery", "text!./style.css"], function ( qlik, $, cssContent ) {
	//'use strict';
	
	$( "<style>" ).html( cssContent ).appendTo( "head" );
	
	var fiter_array = function fiter_array(arr, position, value) {
	  return arr.filter(function (e) {
		return e[position].qText === value;
	  });
	};

	var unique_values = function unique_values(arr, position) {
	  return arr.map(function (e) {
		return e[position].qText;
	  }).filter(function (v, i, a) {
		return a.indexOf(v) === i;
	  });
	};

	function buildList(data){
		var html = '';
		html += '<ul>';
		for(item in data){
			if(typeof(data[item].sub) === 'object'){ // An array will return 'object'
				html += '<li class="list-item"><a href="#">' + data[item].name +'</a>';
				html +=  buildList(data[item].sub); // Submenu found. Calling recursively same method
			} else {
				html +=  '<li class="list-item list-item--select"><a href="#">'+ data[item].name +'</a>' // No submenu
			}
			html += '</li>';
		}
		html += '</ul>';
		return html;
	}
	
	function transformValues (qMatrix, colcount, dimensionInfo) {
		return unique_values(qMatrix, 0)
				  .filter(function (e) {
					return e !== undefined;
				  })
				  .map(function (e) {
					return {
					  name: e,
					  title: dimensionInfo[0].qFallbackTitle,
					};
				  })
				  .map(function (e) {
				  	if(colcount===1) return e;
					
					var getElements = function getElements(element, iterNo, prevArr) {
					  if (prevArr !== undefined) {
						arr = fiter_array(prevArr, iterNo, element.name);
					  }

					  arr = fiter_array(qMatrix, iterNo, element.name);
					  var elem = unique_values(arr, iterNo + 1).filter(function (e) {
						return e !== undefined;
					  });

					  var res = {
						name: element.name,
						sub: elem.map(function (e) {
						  return {
							name: e,
              				title: dimensionInfo[iterNo + 1].qFallbackTitle,
						  };
						}),
					  };

					  if (iterNo + 1 < colcount - 1) {
						res = res.sub.map(function (e) {
						  return getElements(e, iterNo + 1, arr);
						});
					  }
					  if (iterNo === 0)
						return {
						  name: element.name,
						  sub: res,
						  title: element.title,
						};
					  return {
						name: element.name,
						sub: res.sub,
						title: dimensionInfo[iterNo].qFallbackTitle,
					  };
					};

					return getElements(e, 0);
				  });
	}
	
	return {
		initialProperties: {
			qHyperCubeDef: {
				qDimensions: [],
				qMeasures: [],
				qInitialDataFetch: [{
					qWidth: 5,
					qHeight: 1000
				}]
			}
		},
		definition: {
			type: "items",
			component: "accordion",
			items: {
				dimensions: {
					uses: "dimensions",
					min: 1
				},
				measures: {
					uses: "measures",
					min: 0
				},
				sorting: {
					uses: "sorting"
				},
				settings: {
					uses: "settings"
				}
			}
		},
		snapshot: {
			canTakeSnapshot: false
		},
		paint: function ( $element, layout ) {
			var self = this,
				app = qlik.currApp(this)
				hypercube = layout.qHyperCube,
				rowcount = hypercube.qDataPages[0].qMatrix.length,
				dimensionInfo = hypercube.qDimensionInfo,
				colcount = dimensionInfo.length;
				
			var html = '<nav id="menu" class="left show"></nav>';
			$element.html( html );
			
			var values = transformValues(hypercube.qDataPages[0].qMatrix,colcount,dimensionInfo)
			
			console.log(values)
			function buildList(data) {
			  var html = "";
			  html += "<ul>";
			  for (item in data) {
				if (typeof data[item].sub === "object") {
				  // An array will return 'object'
				  html += '<li class="list-item"><a href="#">' + data[item].name + "</a>";
				  html += buildList(data[item].sub); // Submenu found. Calling recursively same method
				} else {
				  html +=
					'<li class="list-item list-item--select"><a href="#" title="' +
					data[item].title +
					'">' +
					data[item].name +
					"</a>"; // No submenu
				}
				html += "</li>";
			  }
			  html += "</ul>";
			  return html;
			}

			$("#menu").html(buildList(values));

			$("#menu a").click(function (event) {
			  event.preventDefault();
			  if ($(this).next("ul").length) {
				$(this).next().toggle("fast");
			  } else {				
				app.field($(this).attr("title")).selectValues([$(this).html()],false,false)
			  }
			});
			
			
			return qlik.Promise.resolve();
		}
	};
} );
